<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<link rel="stylesheet" href="css/index.css">
<link rel="stylesheet" href="css/bootstrap.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>


</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<!-- start 轮播图 -->
	<div id="myCarousel" class="carousel slide">
	<!-- 轮播（Carousel）指标 -->
		<ol class="carousel-indicators">
			<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
			<li data-target="#myCarousel" data-slide-to="1"></li>
			<li data-target="#myCarousel" data-slide-to="2"></li>
		</ol>   
	<!-- 轮播（Carousel）项目 -->
	<div class="carousel-inner">
		<div class="item active">
			<img src="images/bannner3.jpg" alt="First slide">
		</div>
		<div class="item">
			<img src="images/banner3.jpg" alt="Second slide">
		</div>
		<div class="item">
			<img src="images/banner2.jpg" alt="Third slide">
		</div>
	</div>
	<!-- 轮播（Carousel）导航 -->
		<a class="carousel-control left" href="#myCarousel" 
		   ></a>
		<a class="carousel-control right" href="#myCarousel" 
		   ></a>
	</div>
<!-- /banner-->

<!--这是解决方案Div-->
<div class="solution">
	<div class="container">
		<div class="cententDiv-font">
			<a href="solution.php">解决方案/Solutions More</a>
		</div>
			<div class="mySolid"></div>
		<div class="row">
	<?php
		$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=14 AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,3");
		while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
		?>	
			<div class="col-lg-4 col-md-4 col-xs-4">
				<div class="solution_One">
					<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" />
					<p class="solution-font"><a href="#"><?php echo $row['title']; ?></a></p>
				</div>
			</div>
			<?php
				}
			?>
		</div>
	</div>
</div>
<!--start 关于我们-->
	<div class="aboutUs">
		<div class="cententDiv-font">
			<a href="about.php">关于我们/About us</a>
		</div>
			<div class="mySolid"></div>
			<div class="container">
				<div class="row">
				<?php
		$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=2 AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,4");
		while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
		?>	
					<div class="col-lg-3 col-md-3 col-xs-3">
					    <div class="aboutUs_one">
							<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" />
							<p class="aboutUs_font"><?php echo $row['title']; ?></p>
						</div>
					</div>
				<?php
					}
				?>
			</div>
		</div>
	</div>
<!-- end 关于我们 -->
<!-- start 新闻资讯 -->
		<div class="News">		
				<div class="cententDiv-font"><a href="news.php">新闻资讯/news more</a></div>
						<div class="mySolid"></div>
				<div class="container">
					<div class="row">
						<?php
		$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=4 AND orderid=27 AND checkinfo=true ORDER BY orderid ASC LIMIT 0,1");
		while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
		?>
				<div class="col-lg-6 col-md-6 col-xs-6">
					<div class="font">
						<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" />
							<p><?php echo $row['content']; ?></p>
					</div>  
				</div>   
				<?php
					}
				?>
				<?php
		$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=4 AND orderid BETWEEN 36 AND 43 ORDER BY orderid DESC LIMIT 0,8");
		while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
		?>
		
						
						<div class="col-lg-6 col-md-6 col-xs-6">
							<div class="right">
								<div class="triangle">
									<p><?php echo $row['title']; ?>
									<time><?php echo GetDateMk
									($row['posttime']); ?></time>
									</p>
									
									<p class="myDate"></p>
								</div>
							</div>
						</div>
						
					
					<?php
						}
					?>
				</div>
			</div>
</div>
<!-- mainbody-->
<?php require_once('footer.php'); ?>
</body>
</html>
