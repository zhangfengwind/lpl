<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 8 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/case.css">
<link rel="stylesheet" href="css/bootstrap.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".caselist a.img img").LoadImage({width:100,height:80});
});
</script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
       <div class="shadow"></div>

	<!-- 阴影下面的大图片 -->
		<div class="phone">
			<img src="images/9.1.jpg" alt="">
		</div>
<ol class="breadcrumb">
			<span class="one">解决方案</span>
			<span class="two">您当前的位置：</span>
			<li><a href="index.php">首页</a></li>
			<li class="active">解决方案</li>
		</ol>
			<span class="solid"></span>
		
		<span class="case"><a href="#">案例展示</a></span>
		<span class="case-solid"></span>


	<div clss="centent">
		<div class="container">
			<div class="row">
			<?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=16 AND orderid BETWEEN 57 AND 62  ORDER BY orderid ASC LIMIT 0,3");
					while($row = $dosql->GetArray())
						{
							if($row['linkurl'] != '')$gourl = $row['linkurl'];
							else $gourl = 'javascript:;';
					?>
				<div class="case-phone-one">
					<div class="col-lg-4 col-md-4 col-xs-4">
						<div class="font-one">
							<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
							<p><?php echo $row['title']; ?></p>
						</div>
					</div>
				</div>
				<?php
							}
						?>
			</div>
		</div>
	</div>

	<div class="centent1">
		<div class="container">
			<div class="row">
			<?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=16 AND orderid BETWEEN 57 AND 62  ORDER BY orderid ASC LIMIT 3,6");
					while($row = $dosql->GetArray())
						{
							if($row['linkurl'] != '')$gourl = $row['linkurl'];
							else $gourl = 'javascript:;';
					?>
				<div class="case-phone-one">
					<div class="col-lg-6 col-md-6 col-xs-6">
						<div class="font-one">
							<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
							<p><?php echo $row['title']; ?></p>
						</div>
					</div>
				</div>
				<?php
							}
						?>
			</div>
		</div>
	</div>	
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>