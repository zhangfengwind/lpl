<!-- start 导航栏 -->
	<div class="head navbar-fixed-top">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-xs-3">
					<div class="logo">
						<img src="images/header-logo.png" alt="">
					</div>
				</div>
				<div class="col-lg-9 col-md-9 col-xs-9">
					<div class="navigation">
						<ul>
							<?php echo GetNav(); ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- end 导航栏 -->

