<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 2 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/aboutUs.css">
<link rel="stylesheet" href="css/bootstrap.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
    <div class="shadow"></div>
	<!-- 阴影下面的大图片 -->
		<div class="phone">
			<img src="images/15.1.jpg" alt="">
		</div>
		<ol class="breadcrumb">
			<span class="one">关于我们</span>
			<span class="two">您当前的位置：</span>
			<li><a href="index.php">首页</a></li>
			<li><a href="aboutUs.php">关于我们</a></li>
			
		</ol>
			<span class="solid"></span>

				<div class="about-content">
		<div class="cantainer">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-xs-3">
					<div class="about-content-left">
						<div class="about-left-title">关于我们/About Us</div>
						<nav>
							<ul>
								<li><a href="aboutUs.php">公司简介</a></li>
								<li><a href="aboutUs-honor.php">荣誉资质</a></li>
								<li><a href="#">企业文化</a></li>
								<li><a href="#">董事长致辞</a></li>
								<li><a href="#">公司风采</a></li>
								<li><a href="#">合作伙伴</a></li>
								<li><a href="#">公司地址</a></li>
							</ul>
						</nav>
					</div>
				</div>
				<?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=19 ORDER BY orderid DESC LIMIT 0,1");
					while($row = $dosql->GetArray())
						{
							if($row['linkurl'] != '')$gourl = $row['linkurl'];
							else $gourl = 'javascript:;';
					?>

				<div class="col-lg-9 col-md-9 col-xs-9">
					<div class="about-content-right">
						<div class="centent-right">
							<p><?php echo $row['content']; ?></p>
						</div>
					</div>
				</div>
				<?php
							}
						?>
			</div>
		</div>
	<!-- end 中间 -->
		</div>
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>