<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 4 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/news.css">
<link rel="stylesheet" href="css/bootstrap.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<div class="shadow"></div>

	<!-- 阴影下面的大图片 -->
		<div class="phone">
			<img src="images/5.1.jpg" alt="">
		</div>
	<ol class="breadcrumb">
		<span class="one">新闻资讯</span>
			<span class="two">您当前的位置：</span>
		<li><a href="index.php">首页</a></li>
		<li class="active">新闻资讯</li>
	</ol>
			<span class="solid"></span>

         <span class="solution"><a href="#">新闻资讯</a></span>
		<span class="solution-solid"></span>

<div class="centent">
		<div class="container">
			<div class="row">
			  <?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=4 AND orderid BETWEEN 54 AND 57  ORDER BY orderid ASC LIMIT 0,3");
					while($row = $dosql->GetArray())
						{
							if($row['linkurl'] != '')$gourl = $row['linkurl'];
							else $gourl = 'javascript:;';
					?>
				<div class="news-phone-one">
					<div class="col-lg-3 col-md-3 col-xs-3">
						<div class="one">
							<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
						</div>	
					</div>
					<div class="col-lg-8 col-md-8 col-xs-8 col-lg-offset-1 col-md-offset-1 col-xs-offset-1">
						<div class="font-one"><a href=""><?php echo $row['title']; ?></a><br/><br/>
							<time><?php echo GetDateTime($row['posttime']);?></time><br/><br/>
							<p><?php echo $row['content']; ?></p>
						</div>
					</div>
				</div>
				<?php
							}
						?>
			</div>
		</div>
	</div>
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>