<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>

<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<link rel="stylesheet" href="css/solution.css">
<link rel="stylesheet" href="css/bootstrap.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>


</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<div class="shadow"></div>

	<!-- 阴影下面的大图片 -->
		<div class="phone">
			<img src="images/4.1.jpg" alt="">
		</div>
	<ol class="breadcrumb">
		<span class="one">解决方案</span>
			<span class="two">您当前的位置：</span>
		<li><a href="index.php">首页</a></li>
		<li class="active">解决方案</li>
	</ol>
			<span class="solid"></span>

 <span class="solution"><a href="#">解决方案</a></span>
		<span class="solution-solid"></span>

<div class="container">

	<div class="row">
				<?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=14 AND orderid BETWEEN 50 AND 53  ORDER BY orderid ASC LIMIT 0,3");
					while($row = $dosql->GetArray())
						{
							if($row['linkurl'] != '')$gourl = $row['linkurl'];
							else $gourl = 'javascript:;';
					?>
					<div class="solution-phone-one">
						<div class="col-lg-3 col-md-3 col-xs-3">
							<div class="one">
								<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
							</div>
						</div>
						<div class="col-lg-8 col-md-8 col-xs-8 col-lg-offset-1 col-md-offset-1 col-xs-offset-1">
							<div class="font-one">
								<a href="solution-recommend.html"><?php echo $row['title']; ?></a><br/><br/>
									<time><?php echo GetDateTime($row['posttime']);?></time><br/><br/>
									<p>
									<?php echo $row['content']; ?>
									</p>
							</div>
						</div>
					</div>
					<?php
							}
						?>
				
				</div>
</div>
<!-- mainbody-->
<?php require_once('footer.php'); ?>
</body>
</html>
