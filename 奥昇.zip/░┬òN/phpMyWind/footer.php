<div class="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-xs-6">
					<div class="phone_one">
						<img src="images/header-logo.png" alt="">
							<p>合作热线:4003811998223 公司地址:湖南省长沙市望城坡</p>
							<p>opyright&copy 2014 - 2017 aorise All Rights Reserved</p>
							<p>本栏目文字内容归aorise.cn 所有,任何单位及个人未经许可，不得擅自转摘使用</p>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-xs-6">
					<div class="phone_two">
						<img src="images/houpu_code.png" alt=""><br/>
						奥昇教育公众号
					</div>
				</div>	
			</div>
		</div>
	</div >
